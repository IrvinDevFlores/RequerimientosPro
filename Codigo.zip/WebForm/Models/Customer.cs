﻿using System;

namespace Models
{
  public class Customer
  {
    public Int32 Id { get; set; }
    public String Name { get; set; }
    public String City { get; set; }
  }
}
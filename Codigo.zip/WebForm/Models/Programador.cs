﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Frontend.Models
{
    public class Programador
    {
        public int idUsuario { get; set; }
        public string NombreUsuario { get; set; }
    }
}